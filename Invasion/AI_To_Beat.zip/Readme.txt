AI: Attack Weakest
Author: Ian Glow

This AI attacks the weakest planet with a army from its strongest:

To run call:
java AI

Optionally pass command line IP address and a port as in:
java AI [IP] [PORT]


