/**
 * Class: AI
 * Author: Ian Glow
 * Discription: The most basic AI... It will probably loose
 * To Compile: javac *.java
 * To Run: java AI 
 * Optionally can run with IP and Port: java AI [IP Defualt = 'localhost'] [Port Defualt= '6066']
 */

import java.util.ArrayList;
import java.util.Random;

public class AI {

    //Defualt IP and Port
    public static final String DEFAULT_IP_STRING = "localhost";
    public static final int PORT = 6066;

    public Random rand;

    int mTeamId;
    int mMyPlanet;
    int mNumPlanets;

    //Contructor
    public AI () 
    {
        rand = new Random();
    }

    //Happens When the game begins
    public void onStart(int yourTeamID, int yourFirstPlanetID, int numerOfPlanets)
    {
        mTeamId = yourTeamID;
        mMyPlanet = yourFirstPlanetID;
        mNumPlanets = numerOfPlanets;
    }

    //Happens every in game second
    public void tick()
    {
        attack(mMyPlanet, rand.nextInt(mNumPlanets));
    }

    //Happens when someone gains control of a planet
    public void onPlanetCapture(int newOwnerID, int planetID)
    {
        messageServer("I hope we won!");
    }

    //Happens when the enemy player sends a ship
    public void onEnemySendShips(int enemyPlayerID, int targetPlanetID, int shipStrength)
    {
        messageServer("Scarry!");
    }

    //Happens when the game has ended
    public void onGameOver(boolean weWon)
    {
        if(weWon)
            System.out.println("We Won!!!");
        else
            System.out.println("We Lost :(");
    }

    ////////////////////////////////////////////////////////////////////
    /////Use these commands below to interact with the game        /////
    /////DO NOT EDIT THEM                                          /////
    ////////////////////////////////////////////////////////////////////

    ////QUERUES:////

    //Note that this take time as it has to ask the game
    //Dont do this too much if you really want a fast AI
    public int[] queryPlanetStrengths()
    {
        sNetwork.sendText("Q:");
        return sNetwork.waitForArray();
    }

    public int[] queryPlanetOwners()
    {
        sNetwork.sendText("O:");
        return sNetwork.waitForArray();
    }

    ////Commands:////

    //Send a ship from fromPlanetID planet to targetPlanetID planet
    //Send half of the strength of the planet
    public void attack(int fromPlanetID, int toPlanetID)
    {
        sNetwork.sendText("A:" + fromPlanetID + "," + toPlanetID);
    }

    //Use this to give up
    public void surrender()
    {
        sNetwork.sendText("D:");
    }

    //Just sends text to the server to show onscreen
    public void messageServer(String text)
    {
        sNetwork.sendText("T:" + text);
    }


    ////////////////////////////////////////////////////////////////////
    //////Below and in Network.java are the the guts of the program///// 
    ///// You sould read them to learn how the program works       /////
    //////DO NOT EDIT THE CODE BELOW OR YOU WILL FAIL THE ASSIGMENT/////
    ////////////////////////////////////////////////////////////////////
    private static Network sNetwork;
    private static AI sAI;

    public static void main(String argv[]) throws Exception
    {
        run(new AI(), argv);
    }

    public static void run(AI ai, String[] argv)  throws InterruptedException{
        sAI = ai;

        run(argv.length > 0 ? argv[0] : DEFAULT_IP_STRING,
                argv.length > 1 ? Integer.valueOf(argv[1]) : PORT);
    }

    public static void run(String ip, int port) throws InterruptedException {
        try {
            sNetwork = new Network(sAI, ip, port);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        System.out.println("Connected to game!");

        while(true)
        {
            if(!sAI.update())
                return;

            Thread.sleep(10); //check 100 times a second
        }
    }

    //Returns false if AI should shutdown
    public boolean update()
    {
       if(!sNetwork.update())
       {
           return false;
       }

       return true;
    }

    private void wait(int milliseconds)
    {
        try {
            Thread.sleep(milliseconds);
        } catch (Exception e) { }
    }
    
}