//DO NOT EDIT THE CODE BELOW OR YOU WILL FAIL THE ASSIGMENT
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Stack;

import javax.net.ssl.ExtendedSSLSession;

class Network {
    private AI mAI;
    private Socket mSocket;
	private BufferedReader mReader;
	private DataOutputStream mOutputStream;

    private boolean mGameStarted; 

    private int[] mLastArray;
    private int mClientNum;

    private boolean mWaitingForArray;
    private ArrayList<String> mStack;

    public Network(AI ai, String ip, int port) throws Exception
    {
        mAI = ai;

        mStack = new ArrayList<String>();
        mWaitingForArray = false;

        mSocket = new Socket(ip, port);
        mOutputStream = new DataOutputStream(mSocket.getOutputStream());
        mReader = new BufferedReader(new InputStreamReader(mSocket.getInputStream()));

        mGameStarted = false;
    }

    public void sendText(String text)
    {
        if(mGameStarted == false)
        {
            System.out.println("Failed to send message, the game hasnt started yet!");
            return;
        }

        System.out.println("Sent: " + text);
        try {
            mOutputStream.writeBytes(text + '\n');
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int[] waitForArray()
    {
        mWaitingForArray = true;

        while(mLastArray == null)
        {
            //Sleep then check
            try {
                Thread.sleep(1);
            } catch (Exception e) { }

            if(!update())
                return null;
        }

        mWaitingForArray = false;

        int[] toReturn = mLastArray;
        mLastArray = null;
        return toReturn;
    }
    public void handleMessageFromServer(String fromServer) throws Exception
    {        
        System.out.println("Got: " + fromServer);

        char first = fromServer.charAt(0);
        String data = fromServer.substring(2);
        String[] textVals = data.split(",");

        switch(first)
        {
            //1st val is player, 2nd is your 1st planet, 3rd is numberofplanets
            case 'B':
                mGameStarted = true;
                mClientNum = Integer.valueOf(textVals[0]);
                mAI.onStart(
                    mClientNum,
                    Integer.valueOf(textVals[1]),
                    Integer.valueOf(textVals[2]));
                break;

            //We got the strength/Owner info
            //Handle array of ints
            case 'S':
            case 'O':
                mLastArray = new int[textVals.length];
                for(int i = 0; i < textVals.length; i++)
                {
                    mLastArray[i] = Integer.valueOf(textVals[i]);
                }
                break;

            //A capture happened
            //1st val is player, second is planetId
            case 'C':
             mAI.onPlanetCapture(
                Integer.valueOf(textVals[0]),
                Integer.valueOf(textVals[1]));
                break;
            
            //A ship has been sent
            case 'A':
                int player =  Integer.valueOf(textVals[0]);
                if(player != mClientNum)
                {
                    mAI.onEnemySendShips(
                        player,
                        Integer.valueOf(textVals[1]),
                        Integer.valueOf(textVals[2]));
                }
                break;

            //Game over!
            case 'G':
                int winner = Integer.valueOf(textVals[0]);
                mAI.onGameOver(winner == mClientNum);
                mGameStarted = false;
                System.exit(0);
                break;
            
             case 'T':
                mAI.tick();
                break;
        }
    }

    //Returns false if AI should shutdown
    public boolean update()
    {
        try {
            if(mSocket.isConnected())
            {
                String fromServer = mReader.ready() ? mReader.readLine() : null;
                if(fromServer != null)
                {
                    char first = fromServer.charAt(0);
                    
                    if((first == 'O' || first == 'S'))
                    {
                        handleMessageFromServer(fromServer);
                        mWaitingForArray = false;
                    }
                    else
                    {
                        mStack.add(fromServer);
                    }
                }
     
                if(!mWaitingForArray && mStack.size() > 0)
                {
                    handleMessageFromServer(mStack.remove(0));                    
                }

                return true;
            }
            else
            {
                return false;
            }
        } 
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    } 

    public boolean isGameStarted()
    {
        return mGameStarted;
    }
}